/*
 * Autotester header
 * (C) Adrien 'Adriweb' Bertrand
 * Part of the CEmu project
 * License: GPLv3
 */

#ifndef AUTOTESTER_H
#define AUTOTESTER_H

#include <string>
#include <vector>
#include <unordered_map>
#include <functional>

#include "../../core/defines.h"

namespace cemucore
{
    extern "C" {
        #include "../../core/emu.h"
        #include "../../core/link.h"
        #include "../../core/asic.h"
        #include "../../core/cpu.h"
        #include "../../core/mem.h"
        #include "../../core/keypad.h"
        #include "../../core/lcd.h"
        #include "../../core/extras.h"
    }
}

namespace autotester
{
    struct key_coord_t {
        uint8_t y; // row
        uint8_t x; // col
    };

    struct key_sequence_handlers_t {
        std::function<void(uint8_t row, uint8_t col, bool pressed)> keyEvent;
        std::function<void(unsigned int ms)> delay;
        std::function<void(const std::string& error)> error;
        unsigned int default_hold_ms = 80;
        unsigned int delay_after_step_ms = 50;
    };

    struct hash_params_t {
        std::string description;
        uint32_t start; /* Actually a pointer, for the CE */
        uint32_t size;
        int32_t timeout_ms;
        std::vector<uint32_t> expected_CRCs;
    };

    struct config_t {
        std::string rom;
        std::vector<std::string> transfer_files;
        unsigned int delay_after_key  =  0; /* delay in ms after each "key" action (after release) */
        unsigned int delay_after_step = 80; /* delay in ms after each sequence step */
        struct {
            std::string name;
            bool isASM;
        } target;
        std::vector<std::pair<std::string, std::string>> sequence;
        std::unordered_map<std::string, hash_params_t> hashes;
    };

    extern std::string oldCWD;

    /*
     * Constants usable in the "start" and "size" parameters of the JSON config for the hash params
     * See http://wikiti.brandonw.net/index.php?title=Category:84PCE:RAM:By_Address
     */
    static const std::unordered_map<std::string, unsigned int> hash_consts = {
        { "vram_start",     0xD40000 },  { "vram_16_size",    2*LCD_SIZE },
        { "vram2_start",    0xD52C00 },  { "vram_8_size",       LCD_SIZE },
        { "ram_start",      0xD00000 },  { "ram_size",           0x40000 },
        { "textShadow",     0xD006C0 },  { "textShadow_size",        260 },
        { "cmdShadow",      0xD0232D },  { "cmdShadow_size",         260 },
        { "pixelShadow",    0xD031F6 },  { "pixelShadow_size",      8400 },
        { "pixelShadow2",   0xD052C6 },  { "pixelShadow2_size",     8400 },
        { "cmdPixelShadow", 0xD07396 },  { "cmdPixelShadow_size",   8400 },
        { "plotSScreen",    0xD09466 },  { "plotSScreen_size",     21945 },
        { "saveSScreen",    0xD0EA1F },  { "saveSScreen_size",     21945 },
        { "userMem",        0xD1A881 },
        { "lcdPalette",     0xE30200 },  { "lcdPalette_size",       512 },
        { "cursorImage",    0xE30800 },  { "cursorImage_size",     1024 }
    };

    static const char* varExtensions[] = {
        "8xn",  // 00
        "8xl",
        "8xm",
        "8xy",
        "8xs",
        "8xp",
        "8xp",
        "8ci",
        "8xd",  // 08
        "",
        "",
        "8xw",  // 0B
        "8xc",
        "8xl",  // 0D
        "",
        "8xw",  // 0F
        "8xz",  // 10
        "8xt",  // 11
        "",
        "",
        "",
        "8xv",  // 15
        "",
        "8cg",  // 17
        "8xn",  // 18
        "",
        "8ca",  // 1A
        "8xc",
        "8xn",
        "8xc",
        "8xc",
        "8xc",
        "8xn",
        "8xn",  // 21
        "",
        "8pu",  // 23
        "8ek",  // 24
        "",
        "",
        "",
        "",
    };

    void sendCSC(uint8_t csc);
    void sendKey(uint16_t key);
    void sendLetterKeyPress(char letter);

    bool keyCoordForName(const std::string& name, key_coord_t& coord);
    bool runKeySequence(const std::string& sequence, const key_sequence_handlers_t& handlers);

    bool launchCommand(const std::pair<std::string, std::string>& command);

    bool loadJSONConfig(const std::string& jsonContents);

    std::vector<std::string> globVector(const std::string& pattern);

    bool sendFilesForTest();

    bool doTestSequence();

    /* The global config variable */
    extern config_t config;

    extern bool debugMode;
    extern bool screenshotsMode;
    extern bool ignoreROMfield;
    extern bool configLoaded;

    /* Will be incremented in case of matching CRC */
    extern unsigned int hashesPassed;
    /* Will be incremented in case of non-matching CRC, and used as the return value */
    extern unsigned int hashesFailed;
    /* Will be incremented at each `hash` command */
    extern unsigned int hashesTested;
}

#endif
