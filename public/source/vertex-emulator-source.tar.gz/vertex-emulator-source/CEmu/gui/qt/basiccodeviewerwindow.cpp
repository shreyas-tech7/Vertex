#include "basiccodeviewerwindow.h"
#include "ui_basiccodeviewerwindow.h"

#include "tibasicutils.h"
#include "utils.h"

#include "tivars_lib_cpp/tivars_lib_cpp.hpp"

#include "../../core/mem.h"

#include <QtCore/QSignalBlocker>
#include <QtGui/QPainter>
#include <QtGui/QContextMenuEvent>
#include <QtGui/QKeyEvent>
#include <QtGui/QKeySequence>
#include <QtGui/QMouseEvent>
#include <QtWidgets/QInputDialog>
#include <QtWidgets/QMenu>
#include <QtWidgets/QScrollBar>
#include <QtWidgets/QMessageBox>

namespace {
constexpr int BASIC_EDITOR_MARKER_WIDTH = 22;
constexpr int BASIC_EDITOR_GUTTER_VERTICAL_OFFSET = -2;
}

BasicEditor::BasicEditor(QWidget *parent) : QPlainTextEdit(parent)
{
    highlighter = new BasicHighlighter(document());
    lineNumberArea = new LineNumberArea(this);

    QFont font = QFont(QStringLiteral("TICELarge"), 11);
    lineNumberArea->setFont(font);

    connect(this, &QPlainTextEdit::blockCountChanged, this, &BasicEditor::updateLineNumberAreaWidth);
    connect(this, &QPlainTextEdit::updateRequest, this, &BasicEditor::updateLineNumberArea);
    connect(document(), &QTextDocument::contentsChanged, this, [this] {
        navigationHistory.clear();
    });

    setMouseTracking(true);
    updateLineNumberAreaWidth(0);
}

void BasicEditor::updateDarkMode()
{
    if (highlighter != nullptr) {
        delete highlighter;
        highlighter = new BasicHighlighter(document());
    }
}

void BasicEditor::toggleHighlight()
{
    if (highlighter == nullptr) {
        highlighter = new BasicHighlighter(document());
    } else {
        delete highlighter;
        highlighter = nullptr;
    }
}

int BasicEditor::lineNumberAreaWidth()
{
    int digits = 1;
    int max = qMax(1, blockCount());
    while (max >= 10) {
        max /= 10;
        ++digits;
    }

    int singlespace = fontMetrics().horizontalAdvance(QLatin1Char('9'));

    int space = BASIC_EDITOR_MARKER_WIDTH + 3 + singlespace * digits;

    return space;
}

void BasicEditor::updateLineNumberAreaWidth(int /* newBlockCount */)
{
    setViewportMargins(lineNumberAreaWidth(), 0, 0, 0);
}

void BasicEditor::updateLineNumberArea(const QRect &rect, int dy)
{
    if (dy)
        lineNumberArea->scroll(0, dy);
    else
        lineNumberArea->update(0, rect.y(), lineNumberArea->width(), rect.height());

    if (rect.contains(viewport()->rect()))
        updateLineNumberAreaWidth(0);
}

void BasicEditor::resizeEvent(QResizeEvent *e)
{
    QPlainTextEdit::resizeEvent(e);

    QRect cr = contentsRect();
    lineNumberArea->setGeometry(QRect(cr.left(), cr.top(), lineNumberAreaWidth(), cr.height()));
}

void BasicEditor::lineNumberAreaPaintEvent(QPaintEvent *event) const
{
    QPainter painter(lineNumberArea);
    painter.fillRect(event->rect(), Qt::lightGray);
    painter.setPen(Qt::black);

    QTextBlock block = firstVisibleBlock();
    int blockNumber = block.blockNumber();
    int top = static_cast<int>(blockBoundingGeometry(block).translated(contentOffset()).top());
    int bottom = top + static_cast<int>(blockBoundingRect(block).height());

    while (block.isValid() && top <= event->rect().bottom()) {
        if (block.isVisible() && bottom >= event->rect().top()) {
            if (breakpoints.contains(blockNumber)) {
                constexpr int markerSize = 10;
                const int markerLeft = (BASIC_EDITOR_MARKER_WIDTH - markerSize) / 2;
                const int markerTop = top + (bottom - top - markerSize) / 2 +
                                      BASIC_EDITOR_GUTTER_VERTICAL_OFFSET;
                painter.setPen(Qt::NoPen);
                painter.setBrush(QColor(0xD0, 0x32, 0x32));
                painter.drawEllipse(markerLeft, markerTop, markerSize, markerSize);
            }
            QString number = QString::number(blockNumber + 1);
            painter.setPen(Qt::black);
            painter.drawText(BASIC_EDITOR_MARKER_WIDTH,
                             top + BASIC_EDITOR_GUTTER_VERTICAL_OFFSET,
                             lineNumberArea->width() - BASIC_EDITOR_MARKER_WIDTH - 2,
                             bottom - top, Qt::AlignRight | Qt::AlignVCenter, number);
        }
        block = block.next();
        top = bottom;
        bottom = top + static_cast<int>(blockBoundingRect(block).height());
        ++blockNumber;
    }
}

int BasicEditor::blockNumberAtY(int y) const
{
    QTextBlock block = firstVisibleBlock();
    int top = static_cast<int>(blockBoundingGeometry(block).translated(contentOffset()).top());
    int bottom = top + static_cast<int>(blockBoundingRect(block).height());
    while (block.isValid()) {
        if (y >= top && y < bottom) {
            return block.blockNumber();
        }
        block = block.next();
        top = bottom;
        bottom = top + static_cast<int>(blockBoundingRect(block).height());
    }
    return -1;
}

void BasicEditor::lineNumberAreaMousePressEvent(QMouseEvent *event)
{
    if (event->button() != Qt::LeftButton || !breakpointEditingEnabled) {
        return;
    }
    const int line = blockNumberAtY(event->pos().y());
    if (line < 0) {
        return;
    }
    const bool enabled = !breakpoints.contains(line);
    if (enabled) {
        breakpoints.insert(line);
    } else {
        breakpoints.remove(line);
    }
    lineNumberArea->update();
    emit breakpointToggled(line, enabled);
}

QString BasicEditor::gotoLabelAt(const QPoint &pos) const
{
    const QTextCursor cursor = cursorForPosition(pos);
    const QTextBlock block = cursor.block();
    const int position = cursor.position() - block.position();
    static const QRegularExpression gotoPattern(
        QStringLiteral("\\bGoto\\s+([A-Z0-9θ]{1,2})(?![A-Z0-9θ])"),
        QRegularExpression::CaseInsensitiveOption);
    auto matches = gotoPattern.globalMatch(block.text());
    while (matches.hasNext()) {
        const QRegularExpressionMatch match = matches.next();
        if (position >= match.capturedStart() && position <= match.capturedEnd()) {
            return match.captured(1).toUpper();
        }
    }
    return QString();
}

QStringList BasicEditor::labels() const
{
    QStringList result;
    static const QRegularExpression labelPattern(
        QStringLiteral("\\bLbl\\s+([A-Z0-9θ]{1,2})(?![A-Z0-9θ])"),
        QRegularExpression::CaseInsensitiveOption);
    for (QTextBlock block = document()->begin(); block.isValid(); block = block.next()) {
        auto matches = labelPattern.globalMatch(block.text());
        while (matches.hasNext()) {
            const QString label = matches.next().captured(1).toUpper();
            if (!result.contains(label)) {
                result.append(label);
            }
        }
    }
    result.sort(Qt::CaseInsensitive);
    return result;
}

bool BasicEditor::goToLabel(const QString &label)
{
    const QRegularExpression labelPattern(
        QStringLiteral("\\bLbl\\s+%1(?![A-Z0-9θ])").arg(QRegularExpression::escape(label)),
        QRegularExpression::CaseInsensitiveOption);
    for (QTextBlock block = document()->begin(); block.isValid(); block = block.next()) {
        const QRegularExpressionMatch match = labelPattern.match(block.text());
        if (!match.hasMatch()) {
            continue;
        }
        const int target = block.position() + match.capturedStart();
        if (textCursor().position() != target) {
            navigationHistory.append(textCursor().position());
        }
        QTextCursor cursor(document());
        cursor.setPosition(target);
        cursor.setPosition(target + match.capturedLength(), QTextCursor::KeepAnchor);
        setTextCursor(cursor);
        centerCursor();
        return true;
    }
    return false;
}

bool BasicEditor::goBack()
{
    if (navigationHistory.isEmpty()) {
        return false;
    }
    QTextCursor cursor(document());
    cursor.setPosition(navigationHistory.takeLast());
    setTextCursor(cursor);
    centerCursor();
    return true;
}

void BasicEditor::addCodeContextActions(QMenu *menu, const QPoint &pos)
{
    menu->addSeparator();
    const QString targetLabel = gotoLabelAt(pos);
    if (!targetLabel.isEmpty()) {
        QAction *goToTarget = menu->addAction(tr("Go to Lbl %1").arg(targetLabel));
        connect(goToTarget, &QAction::triggered, this, [this, targetLabel] { goToLabel(targetLabel); });
    }

    const QStringList availableLabels = labels();
    QAction *goToAny = menu->addAction(tr("Go to label…"));
    goToAny->setEnabled(!availableLabels.isEmpty());
    connect(goToAny, &QAction::triggered, this, [this, availableLabels] {
        bool accepted = false;
        const QString label = QInputDialog::getItem(
            this, tr("Go to label"), tr("Label:"), availableLabels, 0, false, &accepted);
        if (accepted) {
            goToLabel(label);
        }
    });

    QAction *back = menu->addAction(tr("Go back"));
    back->setEnabled(!navigationHistory.isEmpty());
    connect(back, &QAction::triggered, this, [this] { goBack(); });
}

void BasicEditor::setBreakpointEditingEnabled(bool enabled)
{
    breakpointEditingEnabled = enabled;
    lineNumberArea->setCursor(enabled ? Qt::PointingHandCursor : Qt::ArrowCursor);
}

void BasicEditor::setBreakpoints(const QSet<int> &lines)
{
    breakpoints = lines;
    lineNumberArea->update();
}

bool BasicEditor::hasBreakpoint(int line) const
{
    return breakpoints.contains(line);
}

void BasicEditor::contextMenuEvent(QContextMenuEvent *event)
{
    QMenu *menu = createStandardContextMenu(event->pos());
    addCodeContextActions(menu, event->pos());
    menu->exec(event->globalPos());
    delete menu;
}

void BasicEditor::keyPressEvent(QKeyEvent *event)
{
    if (event->matches(QKeySequence::Back) && goBack()) {
        event->accept();
        return;
    }
    QPlainTextEdit::keyPressEvent(event);
}

void BasicEditor::mouseMoveEvent(QMouseEvent *event)
{
    const bool modifier = event->modifiers().testFlag(Qt::ControlModifier) ||
                          event->modifiers().testFlag(Qt::MetaModifier);
    viewport()->setCursor(modifier && !gotoLabelAt(event->pos()).isEmpty()
                              ? Qt::PointingHandCursor
                              : Qt::IBeamCursor);
    QPlainTextEdit::mouseMoveEvent(event);
}

void BasicEditor::mouseReleaseEvent(QMouseEvent *event)
{
    const bool modifier = event->modifiers().testFlag(Qt::ControlModifier) ||
                          event->modifiers().testFlag(Qt::MetaModifier);
    if (event->button() == Qt::LeftButton && modifier) {
        const QString label = gotoLabelAt(event->pos());
        if (!label.isEmpty() && goToLabel(label)) {
            event->accept();
            return;
        }
    }
    QPlainTextEdit::mouseReleaseEvent(event);
}

/* Highlighter */

BasicHighlighter::BasicHighlighter(QTextDocument *parent) : QSyntaxHighlighter(parent)
{
    HighlightingRule rule;
    bool darkMode = isRunningInDarkMode();

    numberFormat.setForeground(QColor(darkMode ? "lime" : "darkmagenta"));
    rule.pattern = QRegularExpression(R"((((\b[0-9]+)?\.)?\b[0-9]+(ᴇ⁻?[0-9]+)?))");
    rule.format = numberFormat;
    highlightingRules.append(rule);

    variableFormat.setForeground(QColor(darkMode ? "yellow" : "darkyellow"));
    rule.pattern = QRegularExpression(R"((\[[A-J]\])|([A-Zθ])|([\|?uvw])|((GDB|Str|Pic|Img)[0-9])|([XYr][₁₂₃₄₅₆₇₈₉]ᴛ?)|([XY](min|max|scl|res)))");
    rule.format = variableFormat;
    highlightingRules.append(rule);

    listFormat.setForeground(QColor(darkMode ? "lightblue" : "blue"));
    rule.pattern = QRegularExpression("(⌊[A-Zθ][A-Z0-9θ]{0,4})|(L[₁₂₃₄₅₆₇₈₉])");
    rule.format = listFormat;
    highlightingRules.append(rule);

    keywordFormat.setForeground(QColor(darkMode ? "darkorange" : "darkblue"));
    rule.pattern = QRegularExpression("\\b(Else|End|For|Goto|EndIf|ElseIf|End!If|If|!If|Lbl|Repeat|Return|Stop|Then|While)\\b");
    rule.format = keywordFormat;
    highlightingRules.append(rule);

    builtinFormat.setForeground(darkMode ? Qt::cyan : Qt::darkCyan);
    QStringList builtinPatterns;
    builtinPatterns << "\\bAns\\b" << "\\bAsmComp\\b" << "\\bAsm(8[34]CE?)?Prgm\\b" <<"\\bAUTO\\b"
                    << "\\bAxesOff\\b" << "\\bAxesOn\\b" << "\\bBackgroundOn\\b" << "\\bBackgroundOff\\b"
                    << "\\bCLASSIC\\b" << "\\bClockOff\\b" << "\\bClockOn\\b" << "\\bConnected\\b" << "\\bCoordOff\\b"
                    << "\\bCoordOn\\b" << "\\bDiagnosticOff\\b" << "\\bDiagnosticOn\\b" << "\\bDot\\b" << "\\beval\\b"
                    << "\\bExprOff\\b" << "\\bExprOn\\b" << "\\bFnOff\\b" << "\\bFnOn\\b" << "\\bGridOff\\b"
                    << "\\bGridOn\\b" << "\\bHistogram\\b" << "\\bHoriz\\b" << "\\bLabelOff\\b" << "\\bLabelOn\\b"
                    << "\\bMATHPRINT\\b" << "\\bNormal\\b" << "\\bParam\\b" << "\\bPlot1\\b" << "\\bPlot2\\b"
                    << "\\bPlot3\\b" << "\\bPlotsOff\\b" << "\\bPlotsOn\\b" << "\\bPolar\\b" << "\\bPolarGC\\b"
                    << "\\bprgm\\b" << "\\bReal\\b" << "\\bSetUpEditor\\b" << "\\bWeb\\b" << "\\bZ-Test\\b"
                    << "\\bZBox\\b" << "\\bZDecimal\\b" << "\\bZFrac\\b" << "\\bZInteger\\b" << "\\bZInterval\\b"
                    << "\\bZoom\\b" << "\\bZoomFit\\b" << "\\bZoomRcl\\b" << "\\bZoomStat\\b" << "\\bZoomSto\\b"
                    << "\\bZPrevious\\b" << "\\bZQuadrant1\\b" << "\\bZSquare\\b" << "\\bZStandard\\b" << "\\bZTrig\\b"
                    << "\\babs\\b" << "\\bangle\\b" << "\\bANOVA\\b" << "\\bAnswer\\b" << "\\bArchive\\b" << "\\bAsm\\b"
                    << "\\baugment\\b" << "\\bbal\\b" << "\\bbinomcdf\\b" << "\\bbinompdf\\b" << "\\bBoxplot\\b" << "\\bChange\\b"
                    << "\\bcheckTmr\\b" << "\\bCircle\\b" << "\\bClear\\b" << "\\bClrAllLists\\b" << "\\bClrDraw\\b"
                    << "\\bClrHome\\b" << "\\bEffÉcran\\b" << "\\bClrList\\b" << "\\bClrTable\\b" << "\\bconj\\b"
                    << "\\bcos\\b" << "\\bcosh\\b" << "\\bCubicReg\\b" << "\\bcumSum\\b" << "\\bdayOfWk\\b" << "\\bdbd\\b"
                    << "\\bDec\\b" << "\\bDEC\\b" << "\\bDegree\\b" << "\\bDelVar\\b" << "\\bDependAsk\\b"
                    << "\\bDependAuto\\b" << "\\bdet\\b" << "\\bdim\\b" << "\\bDisp\\b" << "\\bDispGraph\\b"
                    << "\\bDispTable\\b" << "\\bDMS\\b" << "\\bDrawF\\b" << "\\bDrawInv\\b" << "\\bDS\\b" << "\\bEff\\b"
                    << "\\bEng\\b" << "\\bEntries\\b" << "\\bEqu\\b" << "\\bExecLib\\b" << "\\bexpr\\b" << "\\bExpReg\\b"
                    << "\\bFcdf\\b" << "\\bFill\\b" << "\\bFix\\b" << "\\bFloat\\b" << "\\bfMax\\b" << "\\bfMin\\b"
                    << "\\bfnInt\\b" << "\\bfPart\\b" << "\\bFpdf\\b" << "\\bFrac\\b" << "\\bFRAC\\b" << "\\bFull\\b"
                    << "\\bFunc\\b" << "\\bGarbageCollect\\b" << "\\bgcd\\b" << "\\bgeometcdf\\b" << "\\bgeometpdf\\b"
                    << "\\bGet\\b" << "\\bGetCalc\\b" << "\\bgetDate\\b" << "\\bgetDtFmt\\b" << "\\bgetDtStr\\b"
                    << "\\bgetKey\\b" << "\\bgetTime\\b" << "\\bgetTmFmt\\b" << "\\bgetTmStr\\b" << "\\bGraphStyle\\b"
                    << "\\bHorizontal\\b" << "\\bidentity\\b" << "\\bimag\\b" << "\\bIn\\b" << "\\bIndpntAsk\\b"
                    << "\\bIndpntAuto\\b" << "\\bInput\\b" << "\\binString\\b" << "\\bint\\b" << "\\binvNorm\\b"
                    << "\\binvT\\b" << "\\biPart\\b" << "\\birr\\b" << "\\bIS\\b" << "\\bIsClockOn\\b" << "\\blcm\\b"
                    << "\\blength\\b" << "\\bLine\\b" << "\\bLinReg\\b" << "\\bLinRegTInt\\b" << "\\bLinRegTTest\\b"
                    << "\\blist\\b" << "\\bList\\b" << "\\bln\\b" << "\\bLnReg\\b" << "\\blog\\b" << "\\blogBASE\\b"
                    << "\\bLogistic\\b" << "\\bManual\\b" << "\\bFit\\b" << "\\bmatr\\b" << "\\bMatr\\b" << "\\bmax\\b"
                    << "\\bmean\\b" << "\\bMed-Med\\b" << "\\bmedian\\b" << "\\bMenu\\b" << "\\bmin\\b" << "\\bModBoxplot\\b"
                    << "\\bnCr\\b" << "\\bnDeriv\\b" << "\\bNom\\b" << "\\bnormalcdf\\b" << "\\bnormalpdf\\b"
                    << "\\bNormProbPlot\\b" << "\\bnot\\b" << "\\bnPr\\b" << "\\bnpv\\b" << "\\bOff\\b" << "\\bOn\\b"
                    << "\\bOpenLib\\b" << "\\bor\\b" << "\\bOut\\b" << "\\bOutput\\b" << "\\bPause\\b" << "\\bPmt_Bgn\\b"
                    << "\\bPmt_End\\b" << "\\bpoissoncdf\\b" << "\\bpoissonpdf\\b" << "\\bprod\\b" << "\\bPrompt\\b"
                    << "\\bPropZInt\\b" << "\\bPropZTest\\b" << "\\bPt\\b" << "\\bPwrReg\\b" << "\\bPxl\\b" << "\\bPxl-Test\\b"
                    << "\\bPxl-Change\\b" << "\\bQuadReg\\b" << "\\bQuartReg\\b" << "\\bRadian\\b" << "\\brand\\b"
                    << "\\brandBin\\b" << "\\brandInt\\b" << "\\bnbrAléatEnt\\b" << "\\brandIntNoRep\\b" << "\\brandM\\b"
                    << "\\brandNorm\\b" << "\\breal\\b" << "\\bRecallGDB\\b" << "\\bRecallPic\\b" << "\\bRect\\b"
                    << "\\bRectGC\\b" << "\\bref\\b" << "\\bremainder\\b" << "\\bround\\b" << "\\brow\\b" << "\\browSwap\\b"
                    << "\\brref\\b" << "\\bSampFTest\\b" << "\\bSampTInt\\b" << "\\bSampTTest\\b" << "\\bSampZInt\\b"
                    << "\\bSampZTest\\b" << "\\bScatter\\b" << "\\bSci\\b" << "\\bSelect\\b" << "\\bSend\\b" << "\\bSeq\\b"
                    << "\\bSequential\\b" << "\\bsetDate\\b" << "\\bsetDtFmt\\b" << "\\bsetTime\\b" << "\\bsetTmFmt\\b"
                    << "\\bShade\\b" << "\\bShade_t\\b" << "\\bShadeF\\b" << "\\bShadeNorm\\b" << "\\bSimul\\b" << "\\bsin\\b"
                    << "\\bsinh\\b" << "\\bsinh\\b" << "\\bSinReg\\b" << "\\bsolve\\b" << "\\bSortA\\b" << "\\bSortD\\b"
                    << "\\bstartTmr\\b" << "\\bStats\\b" << "\\bstatwizard\\b" << "\\bstdDev\\b" << "\\bStoreGDB\\b"
                    << "\\bStorePic\\b" << "\\bString\\b" << "\\bsub\\b" << "\\bsum\\b" << "\\btan\\b" << "\\bTangent\\b"
                    << "\\btanh\\b" << "\\btcdf\\b" << "\\bTest\\b" << "\\bText\\b" << "\\bTextColor\\b" << "\\bTime\\b"
                    << "\\btimeCnv\\b" << "\\bTInterval\\b" << "\\btoString\\b" << "\\btpdf\\b" << "\\bTrace\\b"
                    << "\\btvm_FV\\b" << "\\btvm_I\\b" << "\\btvm_N\\b" << "\\btvm_Pmt\\b" << "\\btvm_PV\\b" << "\\bUn\\b"
                    << "\\bUnArchive\\b" << "\\buvAxes\\b" << "\\buwAxes\\b" << "\\bVar\\b" << "\\bvariance\\b"
                    << "\\bVertical\\b" << "\\bvwAxes\\b" << "\\bWait\\b" << "\\bxor\\b" << "\\bxyLine\\b";
    foreach (const QString &pattern, builtinPatterns) {
        rule.pattern = QRegularExpression(pattern);
        rule.format = builtinFormat;
        highlightingRules.append(rule);
    }

    constFormat.setForeground(QColor("orange"));
    rule.pattern = QRegularExpression("(BLUE|RED|BLACK|MAGENTA|GREEN|ORANGE|BROWN|NAVY|LTBLUE|YELLOW|WHITE|LTGRAY|MEDGRAY|GRAY|DARKGRAY)");
    rule.format = constFormat;
    highlightingRules.append(rule);

    labelFormat.setForeground(darkMode ? QColor(Qt::magenta) : QColor::fromRgb(0xBD, 0x3B, 0xB1));
    rule.pattern = QRegularExpression("\\b(Lbl|Goto) [A-Z0-9θ]{1,2}\\b");
    rule.format = labelFormat;
    highlightingRules.append(rule);

    prgmFormat.setForeground(QColor::fromRgb(0xCD, 0x5C, 0x5C));
    rule.pattern = QRegularExpression("prgm[A-Z][A-Z0-9θ]{0,7}\\b");
    rule.format = prgmFormat;
    highlightingRules.append(rule);

    delvarFormat.setForeground(darkMode ? Qt::cyan : Qt::darkCyan);
    rule.pattern = QRegularExpression("DelVar ");
    rule.format = delvarFormat;
    highlightingRules.append(rule);

    quotationFormat.setForeground(QColor::fromRgb(0x1A, 0x96, 0x28));
    rule.pattern = QRegularExpression(R"("[^→"]*(→|"|$))");
    rule.format = quotationFormat;
    highlightingRules.append(rule);

    commentFormat.setForeground(darkMode ? Qt::lightGray : Qt::darkGray);

    otherFormat.setForeground(darkMode ? Qt::lightGray : Qt::black);
    rule.pattern = QRegularExpression("→");
    rule.format = otherFormat;
    highlightingRules.append(rule);
}

void BasicHighlighter::highlightBlock(const QString &text)
{
    foreach (const HighlightingRule &rule, highlightingRules) {
        const QRegularExpression expression(rule.pattern);
        QRegularExpressionMatchIterator iter = expression.globalMatch(text);
        while (iter.hasNext()) {
            const auto& match = iter.next();
            if (match.hasMatch()) {
                setFormat(match.capturedStart(), match.capturedLength(), rule.format);
            }
        }
    }

    bool withinString = false;
    for (int pos = 0; pos < text.size(); pos++) {
        const QChar character = text.at(pos);
        if (!withinString && character == QLatin1Char('#')) {
            setFormat(pos, text.size() - pos, commentFormat);
            break;
        }
        if (character == QLatin1Char('"')) {
            withinString = !withinString;
        } else if (withinString && (character == QChar(0x2192) ||
                   (character == QLatin1Char('-') && pos + 1 < text.size() &&
                    text.at(pos + 1) == QLatin1Char('>')))) {
            withinString = false;
        }
    }
    setCurrentBlockState(0);
}

BasicCodeViewerWindow::BasicCodeViewerWindow(QWidget *parent, bool doHighlight, bool doWrap, bool doFormat)
  : QDialog{parent}, ui(new Ui::BasicCodeViewerWindow) {
    ui->setupUi(this);

    // Considering the default values...
    if (!doHighlight) { m_showingHighlighted = false; ui->checkboxHighlighting->setCheckState(Qt::Unchecked); ui->basicEdit->toggleHighlight(); }
    if (doWrap) { m_showingWrapped = true; ui->checkboxLineWrapping->setCheckState(Qt::Checked); }
    if (doFormat) { m_showingFormatted = true; ui->checkboxReformatting->setCheckState(Qt::Checked); }

    connect(ui->checkboxHighlighting, &QCheckBox::toggled, this, &BasicCodeViewerWindow::toggleHighlight);
    connect(ui->checkboxLineWrapping, &QCheckBox::toggled, this, &BasicCodeViewerWindow::toggleWrap);
    connect(ui->checkboxReformatting, &QCheckBox::toggled, this, &BasicCodeViewerWindow::toggleFormat);
    connect(ui->buttonSave, &QPushButton::clicked, this, &BasicCodeViewerWindow::save);
    connect(ui->basicEdit->document(), &QTextDocument::modificationChanged, this, [this] { updateSaveButton(); });
    connect(ui->checkboxArchived, &QCheckBox::toggled, this, [this] { updateSaveButton(); });

    ui->basicEdit->setWordWrapMode(m_showingWrapped ? QTextOption::WrapAtWordBoundaryOrAnywhere : QTextOption::NoWrap);

    // Add special jacobly font
    ui->basicEdit->setFont(QFont(QStringLiteral("TICELarge"), 11));
    setEditable(false);
}

void BasicCodeViewerWindow::setVariableName(const QString &name) {
    m_variableName = name;
    setWindowTitle(tr("Variable viewer") + QStringLiteral(" | ") + m_variableName);
}

void BasicCodeViewerWindow::setOriginalCode(const QString &code, bool reindent) {
    m_originalCode = code;
    m_canReformat = reindent;
    if (reindent) {
        m_formattedCode = QString::fromStdString(tivars::TypeHandlers::TH_Tokenized::reindentCodeString(m_originalCode.toStdString()));
    } else {
        m_formattedCode = m_originalCode;
        if (m_showingFormatted) {
            const QSignalBlocker blocker(ui->checkboxReformatting);
            ui->checkboxReformatting->setChecked(false);
            m_showingFormatted = false;
        }
    }
    ui->checkboxReformatting->setEnabled(m_canReformat);
    showCode();
}

void BasicCodeViewerWindow::setArchived(bool archived) {
    m_originalArchived = archived;
    const QSignalBlocker blocker(ui->checkboxArchived);
    ui->checkboxArchived->setChecked(archived);
    updateSaveButton();
}

void BasicCodeViewerWindow::setEditable(bool editable) {
    m_editable = editable;
    ui->basicEdit->setReadOnly(!editable);
    ui->checkboxArchived->setEnabled(editable);
    ui->buttonSave->setVisible(editable);
    ui->checkboxReformatting->setEnabled(m_canReformat);
    updateSaveButton();
}

void BasicCodeViewerWindow::save() {
    if (!m_savePending) {
        emit saveRequested(ui->basicEdit->toPlainText(), ui->checkboxArchived->isChecked());
    }
}

void BasicCodeViewerWindow::saveStarted() {
    m_savePending = true;
    ui->basicEdit->setReadOnly(true);
    ui->checkboxArchived->setEnabled(false);
    ui->buttonSave->setEnabled(false);
}

void BasicCodeViewerWindow::saveFinished(bool success) {
    if (!m_savePending) {
        return;
    }
    m_savePending = false;
    ui->basicEdit->setReadOnly(!m_editable);
    ui->checkboxArchived->setEnabled(m_editable);
    if (success) {
        m_originalCode = ui->basicEdit->toPlainText();
        m_formattedCode = m_originalCode;
        m_originalArchived = ui->checkboxArchived->isChecked();
        ui->basicEdit->document()->setModified(false);
    }
    updateSaveButton();
}

void BasicCodeViewerWindow::updateSaveButton() {
    const bool changed = ui->basicEdit->document()->isModified() ||
                         ui->checkboxArchived->isChecked() != m_originalArchived;
    ui->buttonSave->setEnabled(m_editable && !m_savePending && changed);
}

void BasicCodeViewerWindow::toggleHighlight() {
    m_showingHighlighted = !m_showingHighlighted;
    ui->basicEdit->toggleHighlight();
    showCode();
}

void BasicCodeViewerWindow::toggleWrap() {
    m_showingWrapped = !m_showingWrapped;
    ui->basicEdit->setWordWrapMode(m_showingWrapped ? QTextOption::WrapAtWordBoundaryOrAnywhere : QTextOption::NoWrap);
    showCode();
}

void BasicCodeViewerWindow::toggleFormat() {
    m_showingFormatted = ui->checkboxReformatting->isChecked();
    const int scrollValue = ui->basicEdit->verticalScrollBar()->value();
    if (m_editable) {
        const bool modified = ui->basicEdit->document()->isModified();
        const QTextCursor oldCursor = ui->basicEdit->textCursor();
        const int oldBlock = oldCursor.blockNumber();
        const int oldColumn = oldCursor.positionInBlock();
        m_originalCode = QString::fromStdString(ti_basic_deindent_source(ui->basicEdit->toPlainText().toStdString()));
        m_formattedCode = QString::fromStdString(
            tivars::TypeHandlers::TH_Tokenized::reindentCodeString(m_originalCode.toStdString()));
        ui->basicEdit->document()->setPlainText(m_showingFormatted ? m_formattedCode : m_originalCode);
        ui->basicEdit->document()->setModified(modified);
        const QTextBlock newBlock = ui->basicEdit->document()->findBlockByNumber(oldBlock);
        if (newBlock.isValid()) {
            QTextCursor newCursor(newBlock);
            newCursor.setPosition(newBlock.position() + qMin(oldColumn, newBlock.length() - 1));
            ui->basicEdit->setTextCursor(newCursor);
        }
    } else {
        ui->basicEdit->document()->setPlainText(m_showingFormatted ? m_formattedCode : m_originalCode);
    }
    ui->basicEdit->verticalScrollBar()->setValue(scrollValue);
    showCode();
}

void BasicCodeViewerWindow::showCode() {
    if (!hasCodeYet) {
        ui->basicEdit->document()->setPlainText(m_showingFormatted ? m_formattedCode : m_originalCode);
        hasCodeYet = true;
    } else {
        ui->basicEdit->update();
    }
}

BasicCodeViewerWindow::~BasicCodeViewerWindow() {
    delete ui;
}

void LineNumberArea::anchor() {} /* weak vtable thing */
