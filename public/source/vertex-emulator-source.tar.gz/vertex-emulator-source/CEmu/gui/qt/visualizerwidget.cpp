#include "visualizerwidget.h"
#include "keypad/keypadwidget.h"
#include "utils.h"

#include <QtWidgets/QPushButton>
#include <QtWidgets/QMessageBox>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QMenu>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QListWidget>

VisualizerWidget::VisualizerWidget(QWidget *parent, const QString &config) : QWidget{parent} {
    QIcon iconRefresh(QPixmap(QStringLiteral(":/icons/resources/icons/refresh.png")));
    QIcon iconLcd(QPixmap(QStringLiteral(":/icons/resources/icons/lcd.png")));
    QIcon iconInfo(QPixmap(QStringLiteral(":/icons/resources/icons/misc.png")));

    m_group = new QGroupBox(this);
    QHBoxLayout *hlayout = new QHBoxLayout(m_group);

    m_config = new QLineEdit(m_group);
    m_config->setFocusPolicy(Qt::ClickFocus);
    m_btnLcd = new QToolButton(m_group);
    m_btnRefresh = new QToolButton(m_group);
    m_btnConfig = new QToolButton(m_group);

    m_btnLcd->setIcon(iconLcd);
    m_btnRefresh->setIcon(iconRefresh);
    m_btnConfig->setIcon(iconInfo);

    hlayout->addWidget(m_config);
    hlayout->addWidget(m_btnRefresh);
    hlayout->addWidget(m_btnLcd);
    hlayout->addWidget(m_btnConfig);

    m_view = new VisualizerDisplayWidget(this);
    m_view->setLayoutDirection(Qt::LeftToRight);

    QVBoxLayout *vlayout = new QVBoxLayout(this);
    vlayout->addWidget(m_group);
    vlayout->addWidget(m_view);
    vlayout->addStretch(1);
    setLayout(vlayout);

    connect(m_config, &QLineEdit::returnPressed, this, &VisualizerWidget::stringToView);
    connect(m_btnRefresh, &QPushButton::clicked, this, &VisualizerWidget::stringToView);
    connect(m_btnLcd, &QPushButton::clicked, this, &VisualizerWidget::showPresets);
    connect(m_btnConfig, &QPushButton::clicked, this, &VisualizerWidget::showConfig);

    if (config.isEmpty()) {
        resetView();
    } else {
        m_config->setText(config);
        stringToView();
    }

    translate();
}

VisualizerWidget::~VisualizerWidget() = default;

void VisualizerWidget::translate() const {
    m_group->setTitle(tr("Settings"));
    m_btnLcd->setToolTip(tr("Preset Configurations"));
    m_btnRefresh->setToolTip(tr("Apply changes"));
    m_btnConfig->setToolTip(tr("Change Configuration"));
}

void VisualizerWidget::showPresets() {
    QMenu menu;
    QAction *preset_1 = menu.addAction(tr("Current LCD State"));
    QAction *preset_2 = menu.addAction(tr("8bpp Buffer 1"));
    QAction *preset_3 = menu.addAction(tr("8bpp Buffer 2"));
    QAction *preset_4 = menu.addAction(tr("Palette View"));

    QAction *item = menu.exec(mapToGlobal(m_btnLcd->pos()));
    if (item == preset_1) {
        resetView();
    } else if (item == preset_2) {
        m_config->setText("d40000,320x240,8bpp,bgr");
        stringToView();
    } else if (item == preset_3) {
        m_config->setText("d52c00,320x240,8bpp,bgr");
        stringToView();
    } else if (item == preset_4) {
        m_config->setText("e30200,32x8,1555bpp,bgr,1000%");
        stringToView();
    }
}

void VisualizerWidget::showConfig() {
    QDialog *dialog = new QDialog;

    QGridLayout *mlayout = new QGridLayout(dialog);
    QGridLayout *glayout = new QGridLayout;
    QHBoxLayout *hlayout = new QHBoxLayout;
    QGridLayout *transformSectionLayout = new QGridLayout;

    QLabel *baseLbl = new QLabel(tr("Base Address"));
    QLineEdit *baseEdit = new QLineEdit(int2hex(m_base, 6));
    QLabel *fpsLbl = new QLabel(QStringLiteral("FPS"));
    QSpinBox *fpsSpin = new QSpinBox;
    QLabel *scaleLbl = new QLabel(tr("Scale"));
    QSpinBox *scaleSpin = new QSpinBox;
    QLabel *widthLbl = new QLabel(tr("Width"));
    QSpinBox *widthSpin = new QSpinBox;
    QLabel *heightLbl = new QLabel(tr("Height"));
    QSpinBox *heightSpin = new QSpinBox;
    QLabel *bppLbl = new QLabel(QStringLiteral("BPP"));
    QComboBox *bppCombo = new QComboBox;
    QLabel *transformLbl = new QLabel(tr("Transforms (top to bottom)"));
    QComboBox *transformCombo = new QComboBox;
    QListWidget *transformList = new QListWidget;
    QPushButton *transformAddBtn = new QPushButton(tr("Add"));
    QPushButton *transformRemoveBtn = new QPushButton(tr("Remove"));
    QPushButton *transformUpBtn = new QPushButton(tr("Move up"));
    QPushButton *transformDownBtn = new QPushButton(tr("Move down"));
    QCheckBox *beboChk = new QCheckBox(QStringLiteral("BEBO"));
    QCheckBox *bepoChk = new QCheckBox(QStringLiteral("BEPO"));
    QCheckBox *bgrChk = new QCheckBox(QStringLiteral("BGR"));
    QCheckBox *gridChk = new QCheckBox(tr("Grid"));
    QPushButton *submitBtn = new QPushButton(tr("Submit"));

    fpsSpin->setRange(1, 1000);
    fpsSpin->setValue(m_fps);

    scaleSpin->setRange(0, 5000);
    scaleSpin->setValue(m_scale);

    widthSpin->setRange(0, 5000);
    widthSpin->setValue(m_width);

    heightSpin->setRange(0, 5000);
    heightSpin->setValue(m_height);

    bepoChk->setChecked(m_control & 0x400 ? true : false);
    beboChk->setChecked(m_control & 0x200 ? true : false);
    bgrChk->setChecked(m_control & 0x100 ? true : false);
    gridChk->setChecked(m_grid);

    bppCombo->addItem(QStringLiteral("1"));
    bppCombo->addItem(QStringLiteral("2"));
    bppCombo->addItem(QStringLiteral("4"));
    bppCombo->addItem(QStringLiteral("8"));
    bppCombo->addItem(QStringLiteral("16"));
    bppCombo->addItem(QStringLiteral("24"));
    bppCombo->addItem(QStringLiteral("16 (5:6:5)"));
    bppCombo->addItem(QStringLiteral("12 (4:4:4)"));

    bppCombo->setCurrentIndex((m_control >> 1) & 7);

    transformCombo->addItem(tr("Rotate 90° clockwise"), static_cast<int>(VisualizerTransform::Rotate90));
    transformCombo->addItem(tr("Rotate 180°"), static_cast<int>(VisualizerTransform::Rotate180));
    transformCombo->addItem(tr("Rotate 90° counter-clockwise"), static_cast<int>(VisualizerTransform::Rotate270));
    transformCombo->addItem(tr("Flip horizontally"), static_cast<int>(VisualizerTransform::FlipHorizontal));
    transformCombo->addItem(tr("Flip vertically"), static_cast<int>(VisualizerTransform::FlipVertical));
    transformCombo->addItem(tr("Transpose"), static_cast<int>(VisualizerTransform::Transpose));
    transformCombo->addItem(tr("Transpose across anti-diagonal"), static_cast<int>(VisualizerTransform::Transverse));

    auto addTransformItem = [transformCombo, transformList](VisualizerTransform transform) {
        const int comboIndex = transformCombo->findData(static_cast<int>(transform));
        QListWidgetItem *item = new QListWidgetItem(transformCombo->itemText(comboIndex), transformList);
        item->setData(Qt::UserRole, static_cast<int>(transform));
        transformList->setCurrentItem(item);
    };
    for (VisualizerTransform transform : m_transforms) {
        addTransformItem(transform);
    }
    transformList->setToolTip(tr("Transforms are applied from top to bottom"));
    transformList->setDragDropMode(QAbstractItemView::InternalMove);
    transformList->setMaximumHeight(90);

    QHBoxLayout *transformAddLayout = new QHBoxLayout;
    transformAddLayout->addWidget(transformCombo);
    transformAddLayout->addWidget(transformAddBtn);

    QHBoxLayout *transformMoveLayout = new QHBoxLayout;
    transformMoveLayout->addWidget(transformRemoveBtn);
    transformMoveLayout->addWidget(transformUpBtn);
    transformMoveLayout->addWidget(transformDownBtn);

    QVBoxLayout *transformLayout = new QVBoxLayout;
    transformLayout->addLayout(transformAddLayout);
    transformLayout->addWidget(transformList);
    transformLayout->addLayout(transformMoveLayout);

    glayout->addWidget(baseLbl, 0, 0);
    glayout->addWidget(baseEdit, 0, 1);
    glayout->addWidget(fpsLbl, 1, 0);
    glayout->addWidget(fpsSpin, 1, 1);
    glayout->addWidget(scaleLbl, 2, 0);
    glayout->addWidget(scaleSpin, 2, 1);
    glayout->addWidget(widthLbl, 0, 2);
    glayout->addWidget(widthSpin, 0, 3);
    glayout->addWidget(heightLbl, 1, 2);
    glayout->addWidget(heightSpin, 1, 3);
    glayout->addWidget(bppLbl, 2, 2);
    glayout->addWidget(bppCombo, 2, 3);

    hlayout->addWidget(beboChk);
    hlayout->addWidget(bepoChk);
    hlayout->addWidget(bgrChk);
    hlayout->addWidget(gridChk);
    hlayout->addStretch();

    transformSectionLayout->addWidget(transformLbl, 0, 0, Qt::AlignTop);
    transformSectionLayout->addLayout(transformLayout, 0, 1);

    QFrame *settingsSeparator = new QFrame;
    settingsSeparator->setFrameShape(QFrame::HLine);
    settingsSeparator->setFrameShadow(QFrame::Sunken);

    QFrame *submitSeparator = new QFrame;
    submitSeparator->setFrameShape(QFrame::HLine);
    submitSeparator->setFrameShadow(QFrame::Sunken);

    mlayout->addLayout(glayout, 0, 0);
    mlayout->addLayout(hlayout, 1, 0);
    mlayout->addWidget(settingsSeparator, 2, 0);
    mlayout->addLayout(transformSectionLayout, 3, 0);
    mlayout->addWidget(submitSeparator, 4, 0);
    mlayout->addWidget(submitBtn, 5, 0, Qt::AlignRight);

    dialog->setLayout(mlayout);

    connect(transformAddBtn, &QPushButton::clicked, [transformCombo, addTransformItem] {
        addTransformItem(static_cast<VisualizerTransform>(transformCombo->currentData().toInt()));
    });
    connect(transformRemoveBtn, &QPushButton::clicked, [transformList] {
        delete transformList->takeItem(transformList->currentRow());
    });
    connect(transformUpBtn, &QPushButton::clicked, [transformList] {
        const int row = transformList->currentRow();
        if (row > 0) {
            QListWidgetItem *item = transformList->takeItem(row);
            transformList->insertItem(row - 1, item);
            transformList->setCurrentItem(item);
        }
    });
    connect(transformDownBtn, &QPushButton::clicked, [transformList] {
        const int row = transformList->currentRow();
        if (row >= 0 && row + 1 < transformList->count()) {
            QListWidgetItem *item = transformList->takeItem(row);
            transformList->insertItem(row + 1, item);
            transformList->setCurrentItem(item);
        }
    });

    connect(submitBtn, &QPushButton::clicked, [this, dialog, baseEdit,
            fpsSpin, scaleSpin, widthSpin, heightSpin,
            bppCombo, transformList, beboChk, bepoChk, bgrChk, gridChk]{

        m_base = static_cast<uint32_t>(hex2int(baseEdit->text()));

        m_control &= ~14u;
        m_control |= static_cast<unsigned int>(bppCombo->currentIndex() << 1);

        m_fps = fpsSpin->value();
        m_scale = scaleSpin->value();
        m_width = widthSpin->value();
        m_height = heightSpin->value();
        m_grid = gridChk->isChecked();
        m_transforms.clear();
        for (int row = 0; row < transformList->count(); row++) {
            m_transforms.append(static_cast<VisualizerTransform>(
                transformList->item(row)->data(Qt::UserRole).toInt()));
        }

        set_reset(bepoChk->isChecked(), 0x400u, m_control);
        set_reset(beboChk->isChecked(), 0x200u, m_control);
        set_reset(bgrChk->isChecked(), 0x100u, m_control);

        viewToString();

        dialog->close();
    });
    dialog->exec();
}

void VisualizerWidget::stringToView() {
    QStringList string = m_config->text().split(',');
    QRegularExpression hex_reg("^[0-9A-F]{6}$", QRegularExpression::CaseInsensitiveOption);
    QRegularExpression bpp_reg("^\\d{1,6}bpp$", QRegularExpression::CaseInsensitiveOption);
    QRegularExpression fps_reg("^\\d+fps$", QRegularExpression::CaseInsensitiveOption);

    m_fps = 30;
    m_scale = 100;
    m_grid = false;
    m_transforms.clear();

    set_reset(false, 0x400u, m_control);
    set_reset(false, 0x200u, m_control);
    set_reset(false, 0x100u, m_control);

    foreach (QString str, string) {
        str = str.toLower();
        if (!str.compare(QLatin1String("grid"), Qt::CaseInsensitive)) {
            m_grid = true;
        }
        if (!str.compare(QLatin1String("bepo"), Qt::CaseInsensitive)) {
            set_reset(true, 0x400u, m_control);
        }
        if (!str.compare(QLatin1String("bebo"), Qt::CaseInsensitive)) {
            set_reset(true, 0x200u, m_control);
        }
        if (!str.compare(QLatin1String("bgr"), Qt::CaseInsensitive)) {
            set_reset(true, 0x100u, m_control);
        }
        if (str == QLatin1String("rotate90")) {
            m_transforms.append(VisualizerTransform::Rotate90);
        } else if (str == QLatin1String("rotate180")) {
            m_transforms.append(VisualizerTransform::Rotate180);
        } else if (str == QLatin1String("rotate270")) {
            m_transforms.append(VisualizerTransform::Rotate270);
        } else if (str == QLatin1String("fliph")) {
            m_transforms.append(VisualizerTransform::FlipHorizontal);
        } else if (str == QLatin1String("flipv")) {
            m_transforms.append(VisualizerTransform::FlipVertical);
        } else if (str == QLatin1String("transpose")) {
            m_transforms.append(VisualizerTransform::Transpose);
        } else if (str == QLatin1String("transverse")) {
            m_transforms.append(VisualizerTransform::Transverse);
        }
        if (str.contains('x')) {
            QStringList wh = str.split('x');
            if (wh.size() == 2) {
                m_width = wh.at(0).toInt();
                m_height = wh.at(1).toInt();
            }
        }
        if (str.endsWith('%')) {
            str.remove('%');
            m_scale = str.toInt();
            if (m_scale > 5000) {
                m_scale = 5000;
            }
        }
        if (str.length() == 8 && str.at(0) == '0' && str.at(1) == 'x') {
            str.remove(0, 2);
        }
        if (str.length() == 7 && str.at(0) == '$') {
            str.remove(0, 1);
        }
        if (hex_reg.match(str).hasMatch()) {
            m_base = str.toUInt(Q_NULLPTR, 16);
        }
        if (bpp_reg.match(str).hasMatch()) {
            str.chop(3);
            uint8_t bpp;
            switch (str.toUInt()) {
                case 1: bpp = 0; break;
                case 2: bpp = 1; break;
                case 4: bpp = 2; break;
                case 8: bpp = 3; break;
                case 161555: case 1555: bpp = 4; break;
                case 24: case 888: bpp = 5; break;
                case 16: case 565: bpp = 6; break;
                case 12: case 444: bpp = 7; break;
                default: bpp = 255; break;
            }
            if (bpp != 255) {
                m_control &= ~14u;
                m_control |= static_cast<unsigned int>(bpp << 1);
            }
        }
        if (fps_reg.match(str).hasMatch()) {
            str.chop(3);
            m_fps = str.toInt();
            if (m_fps < 1 || m_fps > 1000) { m_fps = 30; }
        }
    }

    viewToString();
}

void VisualizerWidget::resetView() {
    m_width = LCD_WIDTH;
    m_height = LCD_HEIGHT;
    m_base = lcd.upbase;
    m_control = lcd.control;
    m_scale = 100.0;
    m_grid = false;
    m_transforms.clear();
    viewToString();
}

void VisualizerWidget::forceUpdate() {
    stringToView();
}

void VisualizerWidget::viewToString() {
    QString bpp;
    uint32_t bppstep = 1;

    switch ((m_control >> 1) & 7) {
        case 0: bpp = QStringLiteral("1"); bppstep = 1; break;
        case 1: bpp = QStringLiteral("2"); bppstep = 2; break;
        case 2: bpp = QStringLiteral("4"); bppstep = 4; break;
        case 3: bpp = QStringLiteral("8"); bppstep = 8; break;
        case 4: bpp = QStringLiteral("1555"); bppstep = 16; break;
        case 5: bpp = QStringLiteral("888"); bppstep = 32; break;
        case 6: bpp = QStringLiteral("565"); bppstep = 16; break;
        case 7: bpp = QStringLiteral("444"); bppstep = 16; break;
        default: break;
    }

    m_setup.clear();
    m_setup.append(int2hex(m_base, 6).toUpper());
    m_setup.append(QString::number(m_width) + QStringLiteral("x") + QString::number(m_height));
    m_setup.append(bpp + QStringLiteral("bpp"));
    if (m_control & 0x400) { m_setup.append(QStringLiteral("bepo")); }
    if (m_control & 0x200) { m_setup.append(QStringLiteral("bebo")); }
    if (m_control & 0x100) { m_setup.append(QStringLiteral("bgr")); }
    if (m_scale != 100) { m_setup.append(QString::number(m_scale) + QStringLiteral("%")); }
    if (m_fps != 30) { m_setup.append(QString::number(m_fps) + QStringLiteral("fps")); }
    if (m_grid == true) { m_setup.append(QStringLiteral("grid")); }
    for (VisualizerTransform transform : m_transforms) {
        switch (transform) {
            case VisualizerTransform::Rotate90: m_setup.append(QStringLiteral("rotate90")); break;
            case VisualizerTransform::Rotate180: m_setup.append(QStringLiteral("rotate180")); break;
            case VisualizerTransform::Rotate270: m_setup.append(QStringLiteral("rotate270")); break;
            case VisualizerTransform::FlipHorizontal: m_setup.append(QStringLiteral("fliph")); break;
            case VisualizerTransform::FlipVertical: m_setup.append(QStringLiteral("flipv")); break;
            case VisualizerTransform::Transpose: m_setup.append(QStringLiteral("transpose")); break;
            case VisualizerTransform::Transverse: m_setup.append(QStringLiteral("transverse")); break;
        }
    }

    m_config->setText(m_setup.join(","));

    float s = m_scale / 100.0f;
    bool swapDimensions = false;
    for (VisualizerTransform transform : m_transforms) {
        if (transform == VisualizerTransform::Rotate90
                || transform == VisualizerTransform::Rotate270
                || transform == VisualizerTransform::Transpose
                || transform == VisualizerTransform::Transverse) {
            swapDimensions = !swapDimensions;
        }
    }
    float w = (swapDimensions ? m_height : m_width) * s;
    float h = (swapDimensions ? m_width : m_height) * s;

    uint32_t *data;
    uint32_t *data_end;

    emu_set_lcd_ptrs(&data, &data_end, m_width, m_height, m_base, m_control, false);

    m_view->setFixedSize(static_cast<int>(w), static_cast<int>(h));
    m_view->setRefreshRate(m_fps);
    m_view->setConfig(bppstep, m_width, m_height, m_base, m_control, m_grid,
                      m_transforms, data, data_end);
    adjustSize();

    emit configChanged();
}

QString VisualizerWidget::getConfig() const {
    return m_config->text();
}
